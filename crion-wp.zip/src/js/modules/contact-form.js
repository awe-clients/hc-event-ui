export default function initContactForm() {
    const form = document.getElementById("crion-contact-form");
    const feedback = document.getElementById("crion-contact-feedback");

    if (!form || typeof window.crionContactForm === "undefined") {
        return;
    }

    const submitButton = form.querySelector('button[type="submit"]');

    form.addEventListener("submit", (event) => {
        event.preventDefault();

        const formData = new FormData(form);
        formData.append("action", window.crionContactForm.ajaxAction);

        submitButton.disabled = true;
        submitButton.classList.add("opacity-60", "cursor-not-allowed");

        fetch(window.crionContactForm.ajaxUrl, {
            method: "POST",
            body: formData,
            credentials: "same-origin",
        })
            .then((response) => response.json())
            .then((response) => {
                renderFeedback(response.success, response.data && response.data.message);

                if (response.success) {
                    form.reset();
                }
            })
            .catch(() => {
                renderFeedback(false, "Não foi possível enviar sua mensagem agora. Tente novamente mais tarde.");
            })
            .finally(() => {
                submitButton.disabled = false;
                submitButton.classList.remove("opacity-60", "cursor-not-allowed");
            });
    });

    function renderFeedback(success, message) {
        if (!feedback) {
            return;
        }

        feedback.textContent = message || "";
        feedback.classList.remove(
            "hidden",
            "bg-green-100",
            "text-green-800",
            "border-green-300",
            "bg-red-100",
            "text-red-800",
            "border-red-300"
        );
        feedback.classList.add(
            "mb-6",
            "rounded-lg",
            "px-4",
            "py-3",
            "text-sm",
            "font-medium",
            "border",
            success ? "bg-green-100" : "bg-red-100",
            success ? "text-green-800" : "text-red-800",
            success ? "border-green-300" : "border-red-300"
        );

        feedback.scrollIntoView({ behavior: "smooth", block: "center" });
    }
}
