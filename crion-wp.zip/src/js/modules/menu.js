export default function initMenu() {
    const toggleButton = document.getElementById("navbarToggle");
    const mobileNavbar = document.getElementById("mobileNavbar");

    toggleButton.addEventListener("click", () => {
        mobileNavbar.classList.toggle("hidden");
        mobileNavbar.classList.toggle("scale-y-0");
        mobileNavbar.classList.toggle("scale-y-100");
    });
}