import initMenu from './modules/menu.js';
import initContactForm from './modules/contact-form.js';

initMenu();
initContactForm();