<?php

require get_template_directory() . '/functions/cpt/estatisticas.php';
require get_template_directory() . '/functions/cpt/clientes.php';
require get_template_directory() . '/functions/cpt/atividades.php';
require get_template_directory() . '/functions/cpt/portfolio.php';
require get_template_directory() . '/functions/cpt/mensagens_contato.php';
require get_template_directory() . '/functions/forms/contato.php';
require get_template_directory() . '/functions/import/dados-iniciais.php';

function crion_wp_theme_setup() {
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo');
    add_theme_support('title-tag');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption'));
}
add_action('after_setup_theme', 'crion_wp_theme_setup');

function crion_wp_register_menus() {
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'crion-wp'),
        'footer' => __('Footer Menu', 'crion-wp')
    ));
}
add_action('init', 'crion_wp_register_menus');
?>