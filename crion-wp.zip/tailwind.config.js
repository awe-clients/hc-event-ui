/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./pages/**/*.{html,js}",
    "*.php",
  ],
  theme: {
    extend: {
      container: {
        center: true,
        padding: '24px',
      },
      colors: {
        orange: {
          600: '#FF6600',
          1000: '#331400',
        },
        blue: {
          600: '#0F3679',
        },
        neutral: {
          300: '#F0F1F1',
          500: '#C3C5C8',
          600: '#A2A5AA',
          700: '#797D84',
          800: '#494E57',
          900: '#32353C',
        },
      },
      fontFamily: {
        'open-sans': '"Open Sans", sans-serif',
        'inter': '"Inter", sans-serif',
      },
      boxShadow: {
        'drop': '0px 0px 50px 0px rgba(108, 50, 25, 0.15)', // Nome da classe personalizada
      },
    },
  },
  plugins: [],
}

