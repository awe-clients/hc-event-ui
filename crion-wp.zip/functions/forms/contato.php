<?php

define('CRION_CONTACT_FORM_ACTION', 'crion_contact_submit');
define('CRION_CONTACT_TO_EMAIL', 'contato@crioneventos.com.br');

/**
 * Valida, envia o e-mail e registra a mensagem no banco.
 * Compartilhado entre o fallback via POST (sem JS) e o handler AJAX.
 */
function crion_contact_form_process($nome, $email, $assunto, $mensagem) {
    $nome = sanitize_text_field(wp_unslash($nome));
    $email = sanitize_email(wp_unslash($email));
    $assunto = sanitize_text_field(wp_unslash($assunto));
    $mensagem = sanitize_textarea_field(wp_unslash($mensagem));

    if ($nome === '' || $mensagem === '' || !is_email($email)) {
        return array(
            'success' => false,
            'code' => 'invalido',
            'message' => __('Preencha corretamente todos os campos obrigatórios.', 'crion'),
        );
    }

    $site_name = get_bloginfo('name');
    $subject = sprintf('[%s] %s', $site_name, $assunto !== '' ? $assunto : 'Novo contato pelo site');

    $body = "Nome: {$nome}\n";
    $body .= "E-mail: {$email}\n";
    $body .= 'Assunto: ' . ($assunto !== '' ? $assunto : '-') . "\n\n";
    $body .= "Mensagem:\n{$mensagem}\n";

    $headers = array(
        'Content-Type: text/plain; charset=UTF-8',
        sprintf('From: %s <%s>', $site_name, get_option('admin_email')),
        sprintf('Reply-To: %s <%s>', $nome, $email),
    );

    $sent = wp_mail(CRION_CONTACT_TO_EMAIL, $subject, $body, $headers);

    crion_log_contact_submission($nome, $email, $assunto, $mensagem, $sent);

    if (!$sent) {
        return array(
            'success' => false,
            'code' => 'falha',
            'message' => __('Não foi possível enviar sua mensagem agora. Tente novamente mais tarde.', 'crion'),
        );
    }

    return array(
        'success' => true,
        'code' => 'sucesso',
        'message' => __('Mensagem enviada com sucesso! Em breve entraremos em contato.', 'crion'),
    );
}

/**
 * Guarda a mensagem como CPT privado, mesmo se o e-mail falhar,
 * para não perder o contato caso o wp_mail() não entregue.
 */
function crion_log_contact_submission($nome, $email, $assunto, $mensagem, $sent) {
    $post_id = wp_insert_post(array(
        'post_type' => 'mensagem_contato',
        'post_title' => $assunto !== '' ? "{$nome} — {$assunto}" : $nome,
        'post_content' => $mensagem,
        'post_status' => 'private',
    ), true);

    if (is_wp_error($post_id) || !$post_id) {
        return;
    }

    update_post_meta($post_id, '_contato_email', $email);
    update_post_meta($post_id, '_contato_assunto', $assunto);
    update_post_meta($post_id, '_contato_enviado', $sent ? '1' : '0');
}

/**
 * Fallback para quando o JS não carrega: POST normal na própria página + redirect.
 */
function crion_handle_contact_form_submission() {
    if (wp_doing_ajax()) {
        return;
    }

    if (empty($_POST['crion_contact_action']) || $_POST['crion_contact_action'] !== CRION_CONTACT_FORM_ACTION) {
        return;
    }

    $redirect_url = remove_query_arg('contato', wp_get_referer() ?: home_url('/'));

    if (!isset($_POST['crion_contact_nonce']) || !wp_verify_nonce($_POST['crion_contact_nonce'], 'crion_contact_form')) {
        wp_safe_redirect(add_query_arg('contato', 'erro', $redirect_url) . '#contatar');
        exit;
    }

    // Honeypot: campo oculto que só bots preenchem. Finge sucesso para não dar pista ao spammer.
    if (!empty($_POST['crion_contact_hp'])) {
        wp_safe_redirect(add_query_arg('contato', 'sucesso', $redirect_url) . '#contatar');
        exit;
    }

    $result = crion_contact_form_process(
        $_POST['nome'] ?? '',
        $_POST['email'] ?? '',
        $_POST['assunto'] ?? '',
        $_POST['mensagem'] ?? ''
    );

    wp_safe_redirect(add_query_arg('contato', $result['code'], $redirect_url) . '#contatar');
    exit;
}
add_action('init', 'crion_handle_contact_form_submission');

/**
 * Envio via fetch()/AJAX — usado quando o JS está disponível.
 */
function crion_ajax_contact_submit() {
    check_ajax_referer('crion_contact_form', 'crion_contact_nonce');

    if (!empty($_POST['crion_contact_hp'])) {
        wp_send_json_success(array(
            'message' => __('Mensagem enviada com sucesso! Em breve entraremos em contato.', 'crion'),
        ));
    }

    $result = crion_contact_form_process(
        $_POST['nome'] ?? '',
        $_POST['email'] ?? '',
        $_POST['assunto'] ?? '',
        $_POST['mensagem'] ?? ''
    );

    if ($result['success']) {
        wp_send_json_success(array('message' => $result['message']));
    }

    wp_send_json_error(array('message' => $result['message']));
}
add_action('wp_ajax_' . CRION_CONTACT_FORM_ACTION, 'crion_ajax_contact_submit');
add_action('wp_ajax_nopriv_' . CRION_CONTACT_FORM_ACTION, 'crion_ajax_contact_submit');

/**
 * Expõe a URL do admin-ajax.php para o JS do formulário, sem precisar
 * mexer no pipeline de enqueue existente do tema.
 */
function crion_print_contact_form_ajax_config() {
    printf(
        '<script>window.crionContactForm = {ajaxUrl: %s, ajaxAction: %s};</script>',
        wp_json_encode(admin_url('admin-ajax.php')),
        wp_json_encode(CRION_CONTACT_FORM_ACTION)
    );
}

function crion_contact_form_feedback() {
    if (!isset($_GET['contato'])) {
        return;
    }

    $status = sanitize_key($_GET['contato']);

    $messages = array(
        'sucesso' => array(
            'type' => 'success',
            'text' => __('Mensagem enviada com sucesso! Em breve entraremos em contato.', 'crion'),
        ),
        'invalido' => array(
            'type' => 'error',
            'text' => __('Preencha corretamente todos os campos obrigatórios.', 'crion'),
        ),
        'falha' => array(
            'type' => 'error',
            'text' => __('Não foi possível enviar sua mensagem agora. Tente novamente mais tarde.', 'crion'),
        ),
        'erro' => array(
            'type' => 'error',
            'text' => __('Não foi possível validar o envio. Atualize a página e tente novamente.', 'crion'),
        ),
    );

    if (!isset($messages[$status])) {
        return;
    }

    $message = $messages[$status];
    $classes = $message['type'] === 'success'
        ? 'bg-green-100 text-green-800 border border-green-300'
        : 'bg-red-100 text-red-800 border border-red-300';

    printf(
        '<div class="mb-6 rounded-lg px-4 py-3 text-sm font-medium %s">%s</div>',
        esc_attr($classes),
        esc_html($message['text'])
    );
}

function crion_render_contact_form() {
    crion_contact_form_feedback();
    ?>
    <div id="crion-contact-feedback" class="hidden"></div>

    <form id="crion-contact-form" action="<?php echo esc_url(home_url('/') . '#contatar'); ?>" method="post" class="grid grid-cols-12 gap-6">
        <?php wp_nonce_field('crion_contact_form', 'crion_contact_nonce'); ?>
        <input type="hidden" name="crion_contact_action" value="<?php echo esc_attr(CRION_CONTACT_FORM_ACTION); ?>">

        <div class="hidden" aria-hidden="true">
            <label for="crion_contact_hp">Não preencha este campo</label>
            <input type="text" id="crion_contact_hp" name="crion_contact_hp" tabindex="-1" autocomplete="off">
        </div>

        <div class="col-span-12 sm:col-span-6">
            <label for="contact-nome" class="form-label">Nome</label>
            <input type="text" id="contact-nome" name="nome" required
                class="form-input"
                placeholder="Digite o seu nome">
        </div>

        <div class="col-span-12 sm:col-span-6">
            <label for="contact-email" class="form-label">E-mail</label>
            <input type="email" id="contact-email" name="email" required
                class="form-input"
                placeholder="Digite o seu e-mail">
        </div>

        <div class="col-span-12">
            <label for="contact-assunto" class="form-label">Assunto</label>
            <input type="text" id="contact-assunto" name="assunto" required
                class="form-input"
                placeholder="Sobre o que você quer falar?">
        </div>

        <div class="col-span-12">
            <label for="contact-mensagem" class="form-label">Mensagem</label>
            <textarea id="contact-mensagem" name="mensagem" rows="6" required
                class="form-input"
                placeholder="Digite a sua mensagem"></textarea>
        </div>

        <div class="col-span-12 flex justify-end">
            <button type="submit" class="button-primary max-w-[278px] w-full sm:w-auto">
                Enviar mensagem
            </button>
        </div>
    </form>
    <?php
}
