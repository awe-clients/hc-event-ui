<?php
/**
 * Importador dos dados estáticos da versão frontend-only do tema (branch main)
 * para as CPTs/ACF criadas na versão WordPress. Ferramentas > Importar Dados Crion.
 *
 * Idempotente: identifica registros já existentes pelo título e não duplica.
 */

function crion_import_sideload_theme_image($relative_path, $title) {
    $existing = get_posts(array(
        'post_type' => 'attachment',
        'title' => $title,
        'posts_per_page' => 1,
        'fields' => 'ids',
    ));

    if (!empty($existing)) {
        return $existing[0];
    }

    $file_path = get_template_directory() . $relative_path;

    if (!file_exists($file_path)) {
        return new WP_Error('arquivo_nao_encontrado', "Arquivo não encontrado no tema: {$relative_path}");
    }

    $filename = wp_basename($file_path);
    $upload = wp_upload_bits($filename, null, file_get_contents($file_path));

    if (!empty($upload['error'])) {
        return new WP_Error('upload_falhou', $upload['error']);
    }

    $filetype = wp_check_filetype($upload['file']);

    $attachment_id = wp_insert_attachment(array(
        'post_title' => $title,
        'post_mime_type' => $filetype['type'],
        'post_status' => 'inherit',
    ), $upload['file']);

    if (is_wp_error($attachment_id)) {
        return $attachment_id;
    }

    require_once ABSPATH . 'wp-admin/includes/image.php';
    $metadata = wp_generate_attachment_metadata($attachment_id, $upload['file']);
    wp_update_attachment_metadata($attachment_id, $metadata);

    return $attachment_id;
}

function crion_import_find_or_create_post($post_type, $title) {
    $existing = get_posts(array(
        'post_type' => $post_type,
        'title' => $title,
        'post_status' => 'any',
        'posts_per_page' => 1,
        'fields' => 'ids',
    ));

    if (!empty($existing)) {
        return array('id' => $existing[0], 'created' => false);
    }

    $post_id = wp_insert_post(array(
        'post_type' => $post_type,
        'post_title' => $title,
        'post_status' => 'publish',
    ), true);

    if (is_wp_error($post_id)) {
        return array('id' => 0, 'created' => false, 'error' => $post_id->get_error_message());
    }

    return array('id' => $post_id, 'created' => true);
}

function crion_run_dados_iniciais_import() {
    $log = array();

    if (!function_exists('update_field')) {
        $log[] = array('type' => 'error', 'text' => 'O plugin ACF precisa estar ativo para importar os dados (os campos não seriam preenchidos corretamente).');
        return $log;
    }

    $estatisticas = array(
        array('titulo' => 'Eventos', 'dado' => '956'),
        array('titulo' => 'Clientes atendidos', 'dado' => '349'),
        array('titulo' => 'Anos de experiência', 'dado' => '10'),
        array('titulo' => 'Parceiros oficiais', 'dado' => '+50'),
    );

    foreach ($estatisticas as $item) {
        $result = crion_import_find_or_create_post('estatisticas', $item['titulo']);

        if (!empty($result['error'])) {
            $log[] = array('type' => 'error', 'text' => "Falha ao criar estatística \"{$item['titulo']}\": {$result['error']}");
            continue;
        }

        if ($result['created']) {
            update_field('estatistica_dado', $item['dado'], $result['id']);
            $log[] = array('type' => 'success', 'text' => "Estatística criada: {$item['titulo']} ({$item['dado']})");
        } else {
            $log[] = array('type' => 'info', 'text' => "Estatística já existia: {$item['titulo']}");
        }
    }

    $atividades = array(
        array('titulo' => 'Eventos corporativos', 'icone' => 'eventos-corporativos-icone.png'),
        array('titulo' => 'Ações promocionais', 'icone' => 'acoes-promocionais-icone.png'),
        array('titulo' => 'Eventos científicos', 'icone' => 'eventos-cientificos-icone.png'),
        array('titulo' => 'Ações de trade marketing', 'icone' => 'acoes-trade-marketing-icone.png'),
    );

    foreach ($atividades as $item) {
        $result = crion_import_find_or_create_post('atividades', $item['titulo']);

        if (!empty($result['error'])) {
            $log[] = array('type' => 'error', 'text' => "Falha ao criar atividade \"{$item['titulo']}\": {$result['error']}");
            continue;
        }

        if ($result['created']) {
            $attachment_id = crion_import_sideload_theme_image('/dist/img/atividades/' . $item['icone'], $item['titulo']);

            if (!is_wp_error($attachment_id)) {
                update_field('imagem_atividade', $attachment_id, $result['id']);
            } else {
                $log[] = array('type' => 'error', 'text' => "Ícone não importado para \"{$item['titulo']}\": " . $attachment_id->get_error_message());
            }

            update_field('titulo_atividade', $item['titulo'], $result['id']);
            $log[] = array('type' => 'success', 'text' => "Atividade criada: {$item['titulo']}");
        } else {
            $log[] = array('type' => 'info', 'text' => "Atividade já existia: {$item['titulo']}");
        }
    }

    $clientes = array(
        array('titulo' => 'Petrobras', 'logo' => 'petrobras.png'),
        array('titulo' => 'Sebrae', 'logo' => 'sebrae.png'),
        array('titulo' => 'Fecomércio', 'logo' => 'logo-fecomercio.png'),
        array('titulo' => 'FIERN', 'logo' => 'fiern.png'),
        array('titulo' => 'Humana Saúde', 'logo' => 'humana-saude.png'),
        array('titulo' => 'Unimed Natal', 'logo' => 'logo_unimed_natal.png'),
        array('titulo' => 'Natal Shopping', 'logo' => 'natal-shopping.png'),
        array('titulo' => 'Seja Digital', 'logo' => 'seja-digital.png'),
        array('titulo' => 'UNP', 'logo' => 'unp.png'),
        array('titulo' => 'Cosern', 'logo' => 'cosern.png'),
    );

    foreach ($clientes as $item) {
        $result = crion_import_find_or_create_post('clientes', $item['titulo']);

        if (!empty($result['error'])) {
            $log[] = array('type' => 'error', 'text' => "Falha ao criar cliente \"{$item['titulo']}\": {$result['error']}");
            continue;
        }

        if ($result['created']) {
            $attachment_id = crion_import_sideload_theme_image('/dist/img/clientes/' . $item['logo'], $item['titulo']);

            if (!is_wp_error($attachment_id)) {
                update_field('imagem_cliente', $attachment_id, $result['id']);
            } else {
                $log[] = array('type' => 'error', 'text' => "Logo não importado para \"{$item['titulo']}\": " . $attachment_id->get_error_message());
            }

            // Na versão estática o link do cliente era só "#" (placeholder, sem URL real).
            // Deixado em branco de propósito — preencher com o link real de cada cliente depois.
            $log[] = array('type' => 'success', 'text' => "Cliente criado: {$item['titulo']}");
        } else {
            $log[] = array('type' => 'info', 'text' => "Cliente já existia: {$item['titulo']}");
        }
    }

    $portfolio = array(
        array('titulo' => 'Cenografia', 'imagem' => 'cenografia.png'),
        array('titulo' => 'Híbrido', 'imagem' => 'hibrido.png'),
        array('titulo' => 'Eventos promocionais', 'imagem' => 'eventos-promocionais.png'),
        array('titulo' => 'Eventos corporativos', 'imagem' => 'eventos-corporativos-2.png'),
    );

    foreach ($portfolio as $item) {
        $result = crion_import_find_or_create_post('portfolio', $item['titulo']);

        if (!empty($result['error'])) {
            $log[] = array('type' => 'error', 'text' => "Falha ao criar item do portfólio \"{$item['titulo']}\": {$result['error']}");
            continue;
        }

        if ($result['created']) {
            $attachment_id = crion_import_sideload_theme_image('/dist/img/' . $item['imagem'], $item['titulo']);

            if (!is_wp_error($attachment_id)) {
                update_field('imagem_portfolio', $attachment_id, $result['id']);
            } else {
                $log[] = array('type' => 'error', 'text' => "Imagem não importada para \"{$item['titulo']}\": " . $attachment_id->get_error_message());
            }

            // Na versão estática o link do item era vazio (href=""). Deixado em branco de propósito.
            $log[] = array('type' => 'success', 'text' => "Item do portfólio criado: {$item['titulo']}");
        } else {
            $log[] = array('type' => 'info', 'text' => "Item do portfólio já existia: {$item['titulo']}");
        }
    }

    $home_page = get_page_by_path('home');

    if (!$home_page) {
        $home_id = wp_insert_post(array(
            'post_type' => 'page',
            'post_title' => 'Home',
            'post_name' => 'home',
            'post_status' => 'publish',
        ), true);

        if (is_wp_error($home_id)) {
            $log[] = array('type' => 'error', 'text' => 'Não foi possível criar a página "Home": ' . $home_id->get_error_message());
            return $log;
        }

        $log[] = array('type' => 'success', 'text' => 'Página "Home" criada.');
    } else {
        $home_id = $home_page->ID;
        $log[] = array('type' => 'info', 'text' => 'Página "Home" já existia.');
    }

    $equipe_attachment_id = crion_import_sideload_theme_image('/dist/img/equipe.png', 'Equipe Crion');

    update_field('titulo_equipe', 'Equipe dedicada', $home_id);
    update_field(
        'descricao_equipe',
        'Contamos com uma equipe inteiramente dedicada, formada 100% por mulheres. Elas trazem autenticidade, paixão e uma busca incansável por criar experiências memoráveis e conexões genuínas.',
        $home_id
    );

    if (!is_wp_error($equipe_attachment_id)) {
        update_field('imagem_equipe', $equipe_attachment_id, $home_id);
    } else {
        $log[] = array('type' => 'error', 'text' => 'Imagem da equipe não importada: ' . $equipe_attachment_id->get_error_message());
    }

    update_field('titulo_clientes', 'Nossos clientes', $home_id);
    update_field(
        'descricao_clientes',
        'Seja qual for o perfil do cliente, estamos prontas para criar, planejar e executar as mais diversas ações, sempre integrando estratégias e soluções efetivas.',
        $home_id
    );
    update_field('email_contato', 'contato@crioneventos.com.br', $home_id);
    update_field('endereco_contato', 'R. Touros, 2506 | Natal - RN', $home_id);
    update_field('telefone_contato', '(84) 9 9100 8680', $home_id);

    $log[] = array('type' => 'success', 'text' => 'Campos da página "Home" atualizados.');

    return $log;
}

function crion_register_import_admin_page() {
    add_management_page(
        __('Importar Dados Iniciais', 'crion'),
        __('Importar Dados Crion', 'crion'),
        'manage_options',
        'crion-importar-dados',
        'crion_render_import_admin_page'
    );
}
add_action('admin_menu', 'crion_register_import_admin_page');

function crion_render_import_admin_page() {
    $log = array();

    if (isset($_POST['crion_import_nonce']) && wp_verify_nonce($_POST['crion_import_nonce'], 'crion_import_dados')) {
        $log = crion_run_dados_iniciais_import();
    }
    ?>
    <div class="wrap">
        <h1><?php esc_html_e('Importar Dados Iniciais - Crion', 'crion'); ?></h1>
        <p>
            <?php esc_html_e('Cria as Estatísticas, Atividades e Clientes com os dados da versão estática do site (branch main) e preenche os campos da página "Home". Só cria o que ainda não existe — pode clicar mais de uma vez sem duplicar.', 'crion'); ?>
        </p>

        <?php if (!function_exists('update_field')) : ?>
            <div class="notice notice-error">
                <p><?php esc_html_e('O plugin ACF precisa estar ativo para importar os dados.', 'crion'); ?></p>
            </div>
        <?php endif; ?>

        <form method="post">
            <?php wp_nonce_field('crion_import_dados', 'crion_import_nonce'); ?>
            <?php submit_button(__('Importar dados agora', 'crion')); ?>
        </form>

        <?php if (!empty($log)) : ?>
            <h2><?php esc_html_e('Resultado', 'crion'); ?></h2>
            <ul style="list-style: disc; margin-left: 20px;">
                <?php foreach ($log as $entry) :
                    $color = '#646970';
                    if ($entry['type'] === 'success') {
                        $color = '#1a7f37';
                    } elseif ($entry['type'] === 'error') {
                        $color = '#b32d2e';
                    }
                ?>
                    <li style="color: <?php echo esc_attr($color); ?>;">
                        <?php echo esc_html($entry['text']); ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>
    <?php
}
