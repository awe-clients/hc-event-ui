<?php
function crion_register_cpt_atividades() {
    $labels = array(
        'name'               => _x('Atividades', 'post type general name', 'crion'),
        'singular_name'      => _x('Atividade', 'post type singular name', 'crion'),
        'menu_name'          => _x('Atividades', 'admin menu', 'crion'),
        'name_admin_bar'     => _x('Atividade', 'add new on admin bar', 'crion'),
        'add_new'            => _x('Adicionar Nova', 'atividade', 'crion'),
        'add_new_item'       => __('Adicionar Nova Atividade', 'crion'),
        'new_item'           => __('Nova Atividade', 'crion'),
        'edit_item'          => __('Editar Atividade', 'crion'),
        'view_item'          => __('Ver Atividade', 'crion'),
        'all_items'          => __('Todas Atividades', 'crion'),
        'search_items'       => __('Procurar Atividades', 'crion'),
        'parent_item_colon'  => __('Atividades Pai:', 'crion'),
        'not_found'          => __('Nenhuma atividade encontrada.', 'crion'),
        'not_found_in_trash' => __('Nenhuma atividade encontrada na lixeira.', 'crion')
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array('slug' => 'atividades'),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array('title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments')
    );

    register_post_type('atividades', $args);
}

add_action('init', 'crion_register_cpt_atividades');
?>