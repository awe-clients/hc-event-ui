<?php
function crion_register_cpt_portfolio() {
    $labels = array(
        'name'               => _x('Portfólio', 'post type general name', 'crion'),
        'singular_name'      => _x('Item do Portfólio', 'post type singular name', 'crion'),
        'menu_name'          => _x('Portfólio', 'admin menu', 'crion'),
        'name_admin_bar'     => _x('Item do Portfólio', 'add new on admin bar', 'crion'),
        'add_new'            => _x('Adicionar Novo', 'item do portfólio', 'crion'),
        'add_new_item'       => __('Adicionar Novo Item', 'crion'),
        'new_item'           => __('Novo Item', 'crion'),
        'edit_item'          => __('Editar Item', 'crion'),
        'view_item'          => __('Ver Item', 'crion'),
        'all_items'          => __('Todos os Itens', 'crion'),
        'search_items'       => __('Procurar Itens', 'crion'),
        'parent_item_colon'  => __('Itens Pai:', 'crion'),
        'not_found'          => __('Nenhum item encontrado.', 'crion'),
        'not_found_in_trash' => __('Nenhum item encontrado na lixeira.', 'crion')
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array('slug' => 'portfolio'),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'menu_icon'          => 'dashicons-portfolio',
        'supports'           => array('title')
    );

    register_post_type('portfolio', $args);
}

add_action('init', 'crion_register_cpt_portfolio');
?>
