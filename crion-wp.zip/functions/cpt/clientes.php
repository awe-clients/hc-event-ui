<?php
function create_clientes_cpt() {

    $labels = array(
        'name' => _x( 'Clientes', 'Post Type General Name', 'textdomain' ),
        'singular_name' => _x( 'Cliente', 'Post Type Singular Name', 'textdomain' ),
        'menu_name' => _x( 'Clientes', 'Admin Menu text', 'textdomain' ),
        'name_admin_bar' => _x( 'Cliente', 'Add New on Toolbar', 'textdomain' ),
        'archives' => __( 'Arquivos de Clientes', 'textdomain' ),
        'attributes' => __( 'Atributos de Clientes', 'textdomain' ),
        'parent_item_colon' => __( 'Cliente Pai:', 'textdomain' ),
        'all_items' => __( 'Todos os Clientes', 'textdomain' ),
        'add_new_item' => __( 'Adicionar Novo Cliente', 'textdomain' ),
        'add_new' => __( 'Adicionar Novo', 'textdomain' ),
        'new_item' => __( 'Novo Cliente', 'textdomain' ),
        'edit_item' => __( 'Editar Cliente', 'textdomain' ),
        'update_item' => __( 'Atualizar Cliente', 'textdomain' ),
        'view_item' => __( 'Ver Cliente', 'textdomain' ),
        'view_items' => __( 'Ver Clientes', 'textdomain' ),
        'search_items' => __( 'Procurar Cliente', 'textdomain' ),
        'not_found' => __( 'Não encontrado', 'textdomain' ),
        'not_found_in_trash' => __( 'Não encontrado na lixeira', 'textdomain' ),
        'featured_image' => __( 'Imagem em destaque', 'textdomain' ),
        'set_featured_image' => __( 'Definir imagem em destaque', 'textdomain' ),
        'remove_featured_image' => __( 'Remover imagem em destaque', 'textdomain' ),
        'use_featured_image' => __( 'Usar como imagem em destaque', 'textdomain' ),
        'insert_into_item' => __( 'Inserir no Cliente', 'textdomain' ),
        'uploaded_to_this_item' => __( 'Enviado para este Cliente', 'textdomain' ),
        'items_list' => __( 'Lista de Clientes', 'textdomain' ),
        'items_list_navigation' => __( 'Navegação da lista de Clientes', 'textdomain' ),
        'filter_items_list' => __( 'Filtrar lista de Clientes', 'textdomain' ),
    );
    $args = array(
        'label' => __( 'Cliente', 'textdomain' ),
        'description' => __( 'Post Type para Clientes', 'textdomain' ),
        'labels' => $labels,
        'menu_icon' => 'dashicons-businessman',
        'supports' => array('title', 'thumbnail', 'revisions', 'custom-fields',),
        'taxonomies' => array('category', 'post_tag'),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'show_in_admin_bar' => true,
        'show_in_nav_menus' => true,
        'can_export' => true,
        'has_archive' => true,
        'hierarchical' => false,
        'exclude_from_search' => false,
        'show_in_rest' => true,
        'publicly_queryable' => true,
        'capability_type' => 'post',
    );
    register_post_type( 'clientes', $args );

}
add_action( 'init', 'create_clientes_cpt', 0 );
?>