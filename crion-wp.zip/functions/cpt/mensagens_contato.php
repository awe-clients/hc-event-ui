<?php
function crion_register_cpt_mensagens_contato() {
    $labels = array(
        'name' => __('Mensagens de Contato', 'crion'),
        'singular_name' => __('Mensagem de Contato', 'crion'),
        'menu_name' => __('Mensagens de Contato', 'crion'),
        'all_items' => __('Todas as Mensagens', 'crion'),
        'view_item' => __('Ver Mensagem', 'crion'),
        'search_items' => __('Procurar Mensagens', 'crion'),
        'not_found' => __('Nenhuma mensagem encontrada.', 'crion'),
        'not_found_in_trash' => __('Nenhuma mensagem encontrada na lixeira.', 'crion'),
    );

    register_post_type('mensagem_contato', array(
        'labels' => $labels,
        'description' => __('Registro das mensagens enviadas pelo formulário de contato do site.', 'crion'),
        'public' => false,
        'publicly_queryable' => false,
        'exclude_from_search' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_nav_menus' => false,
        'show_in_admin_bar' => false,
        'show_in_rest' => false,
        'capability_type' => 'post',
        'hierarchical' => false,
        'has_archive' => false,
        'supports' => array('title', 'editor'),
        'menu_icon' => 'dashicons-email-alt',
        'menu_position' => 26,
    ));
}
add_action('init', 'crion_register_cpt_mensagens_contato');

function crion_mensagem_contato_columns($columns) {
    $columns['contato_email'] = __('E-mail', 'crion');
    $columns['contato_assunto'] = __('Assunto', 'crion');
    $columns['contato_enviado'] = __('E-mail enviado?', 'crion');

    return $columns;
}
add_filter('manage_mensagem_contato_posts_columns', 'crion_mensagem_contato_columns');

function crion_mensagem_contato_column_content($column, $post_id) {
    switch ($column) {
        case 'contato_email':
            echo esc_html(get_post_meta($post_id, '_contato_email', true));
            break;
        case 'contato_assunto':
            echo esc_html(get_post_meta($post_id, '_contato_assunto', true) ?: '-');
            break;
        case 'contato_enviado':
            echo get_post_meta($post_id, '_contato_enviado', true) === '1'
                ? '✅'
                : '⚠️';
            break;
    }
}
add_action('manage_mensagem_contato_posts_custom_column', 'crion_mensagem_contato_column_content', 10, 2);
