<?php
function create_estatisticas_cpt() {
    $labels = array(
        'name' => _x('Estatísticas', 'Post Type General Name', 'textdomain'),
        'singular_name' => _x('Estatística', 'Post Type Singular Name', 'textdomain'),
        'menu_name' => __('Estatísticas', 'textdomain'),
        'name_admin_bar' => __('Estatística', 'textdomain'),
        'archives' => __('Arquivo de Estatísticas', 'textdomain'),
        'attributes' => __('Atributos de Estatísticas', 'textdomain'),
        'parent_item_colon' => __('Estatística Pai:', 'textdomain'),
        'all_items' => __('Todas Estatísticas', 'textdomain'),
        'add_new_item' => __('Adicionar Nova Estatística', 'textdomain'),
        'add_new' => __('Adicionar Nova', 'textdomain'),
        'new_item' => __('Nova Estatística', 'textdomain'),
        'edit_item' => __('Editar Estatística', 'textdomain'),
        'update_item' => __('Atualizar Estatística', 'textdomain'),
        'view_item' => __('Ver Estatística', 'textdomain'),
        'view_items' => __('Ver Estatísticas', 'textdomain'),
        'search_items' => __('Procurar Estatísticas', 'textdomain'),
        'not_found' => __('Não encontrado', 'textdomain'),
        'not_found_in_trash' => __('Não encontrado no Lixo', 'textdomain'),
        'featured_image' => __('Imagem Destacada', 'textdomain'),
        'set_featured_image' => __('Definir imagem destacada', 'textdomain'),
        'remove_featured_image' => __('Remover imagem destacada', 'textdomain'),
        'use_featured_image' => __('Usar como imagem destacada', 'textdomain'),
        'insert_into_item' => __('Inserir na Estatística', 'textdomain'),
        'uploaded_to_this_item' => __('Enviado para esta Estatística', 'textdomain'),
        'items_list' => __('Lista de Estatísticas', 'textdomain'),
        'items_list_navigation' => __('Navegação da lista de Estatísticas', 'textdomain'),
        'filter_items_list' => __('Filtrar lista de Estatísticas', 'textdomain'),
    );
    $args = array(
        'label' => __('Estatística', 'textdomain'),
        'description' => __('Custom Post Type para Estatísticas', 'textdomain'),
        'labels' => $labels,
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt', 'comments'),
        'taxonomies' => array('category', 'post_tag'),
        'hierarchical' => false,
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'show_in_admin_bar' => true,
        'show_in_nav_menus' => true,
        'can_export' => true,
        'has_archive' => true,
        'exclude_from_search' => false,
        'publicly_queryable' => true,
        'capability_type' => 'post',
    );
    register_post_type('estatisticas', $args);
}

add_action('init', 'create_estatisticas_cpt', 0);
?>