<?php
    get_header(); 

    $theme = get_template_directory_uri();
    $homepage = get_page_by_path('home');
    $homepage_id = null;

    if ($homepage instanceof WP_Post) {
        $homepage_id = $homepage->ID;
    }
?>

<main class="relative" id="quem-somos">
    <div class="bg-white min-h-[500px]">
        <div class="flex">
            <div class="container grid grid-cols-12">
                <div class="col-span-12 lg:col-span-6 py-12 lg:py-28 flex flex-col gap-6">
                    <h1 class="text-black font-bold text-[26px] sm:text-[32px] lg:text-[46px] font-inter mb-0">
                        A <span class="text-orange-600">Crion Promoções & Eventos</span>, é
                        uma empresa Live Marketing
                    </h1>

                    <div class="flex gap-4">
                        <span class="block w-[32px]">
                            <svg xmlns="http://www.w3.org/2000/svg" height="40px" viewBox="0 -960 960 960" width="40px"
                                fill="#FF6600">
                                <path
                                    d="M726.67-446.67v-66.66H880v66.66H726.67ZM776-160l-123.33-92 40-53.33 123.33 92L776-160Zm-81.33-495.33-40-53.34L776-800l40 53.33-121.33 91.34ZM206.67-200v-160h-60q-27.5 0-47.09-19.58Q80-399.17 80-426.67v-106.66q0-27.5 19.58-47.09Q119.17-600 146.67-600H320l200-120v480L320-360h-46.67v160h-66.66Zm246.66-158v-244L338-533.33H146.67v106.66H338L453.33-358ZM560-346v-268q27 24 43.5 58.5T620-480q0 41-16.5 75.5T560-346ZM300-480Z" />
                            </svg>
                        </span>

                        <span class="block text-sm lg:text-xl">
                            <b>Especializada em eventos e ações promocionais,</b> com a credibilidade e reconhecimento
                            dos seus clientes e parceiros.
                        </span>
                    </div>

                    <div class="flex gap-4">
                        <span class="block w-[32px]">
                            <svg xmlns="http://www.w3.org/2000/svg" height="40px" viewBox="0 -960 960 960" width="40px"
                                fill="#FF6600">
                                <path
                                    d="M480.06-486.67q30.27 0 51.77-21.56 21.5-21.55 21.5-51.83 0-30.27-21.56-51.77-21.55-21.5-51.83-21.5-30.27 0-51.77 21.56-21.5 21.55-21.5 51.83 0 30.27 21.56 51.77 21.55 21.5 51.83 21.5ZM480-168q129.33-118 191.33-214.17 62-96.16 62-169.83 0-114.86-73.36-188.1-73.36-73.23-179.97-73.23T300.03-740.1q-73.36 73.24-73.36 188.1 0 73.67 63 169.83Q352.67-286 480-168Zm0 88Q319-217 239.5-334.5T160-552q0-150 96.5-239T480-880q127 0 223.5 89T800-552q0 100-79.5 217.5T480-80Zm0-480Z" />
                            </svg>
                        </span>

                        <span class="block text-sm lg:text-xl">
                            Com <b>sede no Rio Grande do Norte, </b> atende toda a região Nordeste e demais regiões do
                            Brasil.
                        </span>
                    </div>

                    <!-- <a href="#contatar" class="inline-block bg-blue-600 rounded-md px-8 py-4 w-full max-w-[278px] text-white uppercase text-lg text-center font-bold">
                        Contato
                    </a> -->
                </div>
                <div class="col-span-12 lg:col-span-6 pb-12 lg:py-28">
                    <img src="<?= $theme; ?>/dist/img/image-hero.png" alt="">
                </div>
            </div>
        </div>
    </div>

    <div
        class="bg-white rounded-lg w-full max-w-[1146px] lg:absolute lg:inset-x-0 lg:transform lg:-translate-y-1/3 py-16 px-20 mx-auto lg:shadow-drop">
        <div class="grid gap-6 lg:gap-2 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
            <?php
                $args = array(
                    'post_type' => 'estatisticas',
                    'posts_per_page' => -1
                );
                $estatisticas = new WP_Query($args);

                if ($estatisticas->have_posts()) :
                    while ($estatisticas->have_posts()) : $estatisticas->the_post();
                ?>
            <div class="col-span-1 flex flex-col gap-2">
                <span class="text-orange-600 text-6xl font-inter text-center font-bold">
                    <?= get_field('estatistica_dado'); ?>
                </span>
                <span class="text-center font-semibold text-xl">
                    <?= get_the_title(); ?>
                </span>
            </div>
            <?php
                    endwhile;
                    wp_reset_postdata();
                endif;
            ?>
        </div>
    </div>
</main>

<section class="pb-24 lg:py-60 bg-white">
    <div class="container">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div class="col-span-1">
                <div class="flex gap-6 justify-center">
                    <svg width="25" height="24" viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M20.5 4H4.5C3.39543 4 2.5 4.89543 2.5 6V18C2.5 19.1046 3.39543 20 4.5 20H20.5C21.6046 20 22.5 19.1046 22.5 18V6C22.5 4.89543 21.6046 4 20.5 4Z"
                            stroke="#FF6600" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                        <path
                            d="M22.5 7L13.53 12.7C13.2213 12.8934 12.8643 12.996 12.5 12.996C12.1357 12.996 11.7787 12.8934 11.47 12.7L2.5 7"
                            stroke="#FF6600" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>

                    <a href="mailto:<?= get_field('email_contato', $homepage_id); ?>"
                        class="text-base font-bold text-orange-1000">
                        <?= get_field('email_contato', $homepage_id); ?>
                    </a>
                </div>
            </div>
            <div class="col-span-1">
                <div class="flex gap-6 justify-center">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M20 10C20 14.993 14.461 20.193 12.601 21.799C12.4277 21.9293 12.2168 21.9998 12 21.9998C11.7832 21.9998 11.5723 21.9293 11.399 21.799C9.539 20.193 4 14.993 4 10C4 7.87827 4.84285 5.84344 6.34315 4.34315C7.84344 2.84285 9.87827 2 12 2C14.1217 2 16.1566 2.84285 17.6569 4.34315C19.1571 5.84344 20 7.87827 20 10Z"
                            stroke="#FF6600" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                        <path
                            d="M12 13C13.6569 13 15 11.6569 15 10C15 8.34315 13.6569 7 12 7C10.3431 7 9 8.34315 9 10C9 11.6569 10.3431 13 12 13Z"
                            stroke="#FF6600" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>

                    <p class="text-base font-bold text-orange-1000">
                        <?= get_field('endereco_contato', $homepage_id); ?>
                    </p>
                </div>
            </div>
            <div class="col-span-1">
                <div class="flex gap-6 justify-center">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M22.0001 16.9201V19.9201C22.0012 20.1986 21.9441 20.4743 21.8326 20.7294C21.721 20.9846 21.5574 21.2137 21.3521 21.402C21.1469 21.5902 20.9046 21.7336 20.6408 21.8228C20.377 21.912 20.0974 21.9452 19.8201 21.9201C16.7429 21.5857 13.7871 20.5342 11.1901 18.8501C8.77388 17.3148 6.72539 15.2663 5.19006 12.8501C3.50003 10.2413 2.4483 7.27109 2.12006 4.1801C2.09507 3.90356 2.12793 3.62486 2.21656 3.36172C2.30518 3.09859 2.44763 2.85679 2.63482 2.65172C2.82202 2.44665 3.04986 2.28281 3.30385 2.17062C3.55783 2.05843 3.8324 2.00036 4.11006 2.0001H7.11006C7.59536 1.99532 8.06585 2.16718 8.43382 2.48363C8.80179 2.80008 9.04213 3.23954 9.11005 3.7201C9.23668 4.68016 9.47151 5.62282 9.81006 6.5301C9.9446 6.88802 9.97372 7.27701 9.89396 7.65098C9.81421 8.02494 9.62892 8.36821 9.36005 8.6401L8.09006 9.9101C9.51361 12.4136 11.5865 14.4865 14.0901 15.9101L15.3601 14.6401C15.6319 14.3712 15.9752 14.1859 16.3492 14.1062C16.7231 14.0264 17.1121 14.0556 17.4701 14.1901C18.3773 14.5286 19.32 14.7635 20.2801 14.8901C20.7658 14.9586 21.2095 15.2033 21.5266 15.5776C21.8437 15.9519 22.0122 16.4297 22.0001 16.9201Z"
                            stroke="#FF6600" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>

                    <p class="text-base font-bold text-orange-1000">
                        <?= get_field('telefone_contato', $homepage_id); ?>
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="bg-white pb-16" id="equipe">
    <div class="container">
        <div class="grid grid-cols-1 lg:grid-cols-12 w-fit">
            <div class="col-span-1 lg:col-span-4">
                <h2 class="text-6xl lg:text-[84px] font-bold text-neutral-900 pb-8">
                    <?= get_field('titulo_equipe', $homepage_id); ?>
                </h2>

                <p class="text-xl text-neutral-700 font-medium pb-8">
                    <?= get_field('descricao_equipe', $homepage_id); ?>
                </p>
            </div>
            <div class="col-span-1 lg:col-span-6 lg:col-start-7">
                <img src="<?= get_field('imagem_equipe', $homepage_id); ?>" class="w-full">
            </div>
        </div>
    </div>
</section>

<section class="bg-white pb-16" id="evento">
    <div class="container">
        <h3 class="text-[40px] text-neutral-400 font-bold text-center mb-8">
            Como podemos te ajudar?
        </h3>

        <div class="grid gap-6 lg:gap-2 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
            <?php
                $args = array(
                    'post_type' => 'atividades',
                    'posts_per_page' => -1
                );
                $atividades = new WP_Query($args);

                if ($atividades->have_posts()) :
                    while ($atividades->have_posts()) : $atividades->the_post();
            ?>
            <div class="col-span-1 flex flex-col gap-2 items-center">
                <div class="h-[50px]">
                    <img src="<?= get_field('imagem_atividade'); ?>" alt="<?= get_field('titulo_atividade'); ?>"
                        class="w-[50px]">
                </div>
                <span class="text-center font-semibold text-xl">
                    <?= get_the_title(); ?>
                </span>
            </div>
            <?php
                    endwhile;
                    wp_reset_postdata();
                endif;
            ?>
        </div>
    </div>
</section>

<section class="bg-orange-600 py-8">
    <div class="container flex justify-center gap-8 flex-wrap">
        <h4 class="text-white font-bold text-[44px]">
            Solicite um contato
        </h4>

        <a href="#contatar"
            class="inline-block bg-blue-600 rounded-md px-8 py-4 w-full max-w-[278px] text-white uppercase text-lg text-center font-bold">
            Contato
        </a>
    </div>
</section>

<section class="bg-white py-16" id="clientes">
    <div class="container">
        <div class="flex flex-col items-center mb-8">
            <h2 class="text-6xl lg:text-[84px] font-bold text-neutral-900 pb-8 text-center mb-6">
                <?= get_field('titulo_clientes', $homepage_id); ?>
            </h2>

            <p class="text-xl text-neutral-700 font-medium pb-8 text-center max-w-[855px]">
                <?= get_field('descricao_clientes', $homepage_id); ?>
            </p>
        </div>
        <div class="flex justify-center flex-wrap gap-16">
            <?php
                $args = array(
                    'post_type' => 'clientes',
                    'posts_per_page' => -1
                );
                $clientes = new WP_Query($args);

                if ($clientes->have_posts()) :
                    while ($clientes->have_posts()) : $clientes->the_post();
            ?>
            <a href="<?= get_field('imagem_link'); ?>" target="_blank">
                <img src="<?= get_field('imagem_cliente'); ?>">
            </a>
            <?php
                    endwhile;
                    wp_reset_postdata();
                endif;
            ?>
        </div>
    </div>
</section>

<section class="bg-white py-16" id="portfolio">
    <div class="container">
        <div class="flex flex-wrap justify-center gap-8">
            <?php
                $args = array(
                    'post_type' => 'portfolio',
                    'posts_per_page' => -1
                );
                $portfolio = new WP_Query($args);

                if ($portfolio->have_posts()) :
                    while ($portfolio->have_posts()) : $portfolio->the_post();
                        $link = get_field('link_portfolio');
                        $imagem = get_field('imagem_portfolio');
                        $tag = $link ? 'a' : 'div';
            ?>
            <<?= $tag ?> <?php if ($link) : ?>href="<?= esc_url($link) ?>"<?php endif; ?>
                class="relative aspect-square overflow-hidden rounded-lg w-full sm:w-[calc(50%-1rem)] lg:w-[calc(25%-1.5rem)]">
                <img src="<?= esc_url($imagem) ?>" class="absolute inset-0 h-full w-full object-cover" alt="<?= esc_attr(get_the_title()) ?>">
                <span
                    class="absolute inset-0 flex items-center justify-center px-4 text-white capitalize text-3xl md:text-2xl lg:text-4xl font-bold text-center">
                    <?= get_the_title() ?>
                </span>
            </<?= $tag ?>>
            <?php
                    endwhile;
                    wp_reset_postdata();
                endif;
            ?>
        </div>
    </div>
</section>

<section id="contatar" class="bg-white py-16">
    <div class="container grid grid-cols-12">
        <div class="bg-neutral-300 col-span-12 lg:col-span-8 lg:col-start-3 rounded-2xl p-10">
            <h4 class="text-neutral-900 text-4xl font-bold font-inter text-center mb-4">
                Fale conosco
            </h4>

            <p class="text-neutral-900 text-base font-inter text-center mb-8">
                Entre em contato conosco para tirar suas dúvidas
            </p>

            <?php crion_render_contact_form(); ?>
        </div>
    </div>
</section>

<?php
    get_footer();
?>