<?php
    $theme = get_template_directory_uri();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crion Eventos</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Open+Sans:ital,wght@0,300..800;1,300..800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo $theme; ?>/dist/css/style.css">
    <link rel="stylesheet" href="<?php echo $theme; ?>/style.css">
    <link rel="stylesheet" href="<?php echo $theme; ?>/style-update.css">

    <?= wp_head(); ?>
</head>
<body class="bg-slate-50">
    <header class="bg-white sticky top-0 z-50 shadow-drop">
        <div class="container flex justify-between items-center py-6">

            <!-- LOGO LG -->
            <a href="<?= home_url('/'); ?>" class="hidden lg:block">
                <img src="<?= $theme ?>/dist/img/logo.png" alt="Logo Crion">
            </a>

            <!-- LOGO MD -->
            <a href="<?= home_url('/'); ?>/pages/index.html"  class="hidden md:block lg:hidden">
                <img src="<?= $theme ?>/dist/img/logo.png" alt="Logo Crion">
            </a>

            <!-- LOGO SM -->
            <a href="<?= home_url('/'); ?>/pages/index.html" class="md:hidden">
                <img src="<?= $theme ?>/dist/img/logo.png" alt="Logo Crion">
            </a>

            <!-- MENU ITEMS -->
            <ul class="menu hidden lg:flex">
                <li class="item active">
                    <a href="#quem-somos" class="">
                        Quem somos
                    </a>
                </li>
                <li class="item">
                    <a href="#equipe" class="">
                        Equipe
                    </a>
                </li>
                <li class="item">
                    <a href="#evento" class="">
                        Evento
                    </a>
                </li>
                <li class="item">
                    <a href="#clientes" class="">
                        Clientes
                    </a>
                </li>
                <li class="item">
                    <a href="#portfolio" class="">
                        Portfólio
                    </a>
                </li>
                <li class="item-button">
                    <a href="#contatar" class="button-primary">
                        CONTATAR
                    </a>
                </li>
            </ul>

            <!-- MENU TOGGLE BUTTON (mobile) -->
            <button id="navbarToggle" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                Menu
            </button>

        </div>

        <!-- MENU MOBILE -->
        <div id="mobileNavbar" class="container hidden pb-6">
            <ul class="menu menu-mobile">
                <li class="item active">
                    <a href="#quem-somos" class="">
                        Quem somos
                    </a>
                </li>
                <li class="item">
                    <a href="#equipe" class="">
                        Equipe
                    </a>
                </li>
                <li class="item">
                    <a href="#evento" class="">
                        Evento
                    </a>
                </li>
                <li class="item">
                    <a href="#clientes" class="">
                        Clientes
                    </a>
                </li>
                <li class="item">
                    <a href="#portfolio" class="">
                        Portfólio
                    </a>
                </li>
                <li class="item-button">
                    <a href="#contatar" class="button-primary">
                        CONTATAR
                    </a>
                </li>
            </ul>
        </div>
    </header>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const menuItems = document.querySelectorAll('.menu .item a, .menu-mobile .item a');
        const sections = document.querySelectorAll('section');

        function changeActiveClass() {
            let index = sections.length;

            while(--index && window.scrollY < sections[index].offsetTop) {}

            menuItems.forEach((link) => link.parentElement.classList.remove('active'));
            menuItems[index].parentElement.classList.add('active');
        }

        changeActiveClass();
        window.addEventListener('scroll', changeActiveClass);

        menuItems.forEach((item) => {
            item.addEventListener('click', function() {
                menuItems.forEach((link) => link.parentElement.classList.remove('active'));
                this.parentElement.classList.add('active');
            });
        });
    });
    </script>