<?php
    $theme = get_template_directory_uri();
?>

    <footer class="border-t border-t-neutral-200 border-t-1 py-8 bg-white">
        <div class="container">
            <div class="flex justify-center pb-4">
                <ul class="menu-footer flex-wrap justify-center">
                    <li class="item active">
                        <a href="#quem-somos" class="">
                            Quem somos
                        </a>
                    </li>
                    <li class="item">
                        <a href="#equipe" class="">
                            Equipe
                        </a>
                    </li>
                    <li class="item">
                        <a href="#evento" class="">
                            Evento
                        </a>
                    </li>
                    <li class="item">
                        <a href="#clientes" class="">
                            Clientes
                        </a>
                    </li>
                    <li class="item">
                        <a href="#portfolio" class="">
                            Portfólio
                        </a>
                    </li>
                </ul>
            </div>

            <p class="text-neutral-500 font-inter text-center">
                Copyright ©<?= date('Y'); ?> Crion Promoções e Eventos todos os direitor reservados
            </p>
        </div>
    </footer>

    <?= wp_footer(); ?>

    <?php crion_print_contact_form_ajax_config(); ?>
    <script type="module" src="<?= $theme ?>/src/js/index.js"></script>
</body>
</html>